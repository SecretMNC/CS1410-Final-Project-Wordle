"""Run the app by starting this module."""
from main_menu import WordleMainMenu

if __name__ == "__main__":
    WordleMainMenu()
