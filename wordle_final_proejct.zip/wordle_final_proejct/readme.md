
# Welcome to Wordle!

To start playing, open a bash terminal in this folder and type:

**python3 main.py**
or
**python main.py**

To learn how to play, press the *How to Play* button in the main menu of the game.

